package com.example.kaiburr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaiburrApplicationTests {

	@Test
	void contextLoads() {
	}

}
